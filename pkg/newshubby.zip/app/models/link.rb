class Link < ActiveRecord::Base
  belongs_to :company_launch
end
