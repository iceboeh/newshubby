class Funding < ActiveRecord::Base
  belongs_to :newsroom
end
