class Contact < ActiveRecord::Base
end
