class Code < ActiveRecord::Base
  

  
end
