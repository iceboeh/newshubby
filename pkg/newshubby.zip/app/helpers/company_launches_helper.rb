module CompanyLaunchesHelper
  
end
